wp.blocks.registerBlockVariation( 
	'core/search', 
	{
		name: 'international-search',
		title: 'international',
		attributes: {
			query: {
				cat: '118'
			}
		}
	} 
);