// For English 
wp.blocks.registerBlockVariation( 
	'core/search', 
	{
		name: 'international-search',
		title: 'international',
		attributes: {
			query: {
				cat: '118'
			}
		}
	} 
);
// For Italian
wp.blocks.registerBlockVariation( 
	'core/search', 
	{
		name: 'italian-search',
		title: 'lingua italiana',
		attributes: {
			query: {
				cat: '4'
			}
		}
	} 
);